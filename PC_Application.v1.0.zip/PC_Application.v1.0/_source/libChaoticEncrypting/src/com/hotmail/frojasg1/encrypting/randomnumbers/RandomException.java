/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hotmail.frojasg1.encrypting.randomnumbers;

/**
 *
 * @author Fran
 */
public class RandomException extends Exception
{
  public RandomException( String text ) { super(text);  }
}
