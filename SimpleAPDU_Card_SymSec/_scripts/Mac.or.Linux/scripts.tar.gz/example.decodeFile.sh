#!/bin/bash

PASSWORD=

./decodeFile.sh "./text.100_KB.txt.jfe" "$PASSWORD"

if (( $? == 0 ))
then
    echo "Decryption successful"
else
    echo "Error in decryption"
fi
