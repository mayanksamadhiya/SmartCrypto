#!/bin/bash

PASSWORD=

./encodeFile.sh ./text.100_KB.txt "$PASSWORD"

if (( $? == 0 ))
then
    echo "Encryption successful"
else
    echo "Error in encryption"
fi

