#!/bin/bash


APPLICATION_FOLDER=../../_binary

#########################################################################
# These are the parameters you can use to encode a file:
# -password    followed by a parameter with the password
# -encodedFileName   followed by a parameter with the encoded file name
# -decodedFileName   followed by a parameter with the decoded file name
# -encode or -decode to choose between encryption and decryption
# -fileEncoderType   followed by the id of the fileEncoderType (1 deprecated or 2)   (only for encrypting)
# -sizeOfNumbersSimpleEncoder followed by the size of the numbers for the step 1 (XOR)   (only for encrypting)
# -sizeOfNumbersReordererEncoder followed by the size of the numbers for the step 2 (reordering)   (only for encrypting)
# -numberOfBitsPerIterationSimpleEncoder followed by the number of bits to be returned by the pseudorandom generator in every iteration for the step 1 (XOR)   (only for encrypting)
# -numberOfBitsPerIterationReordererEncoder followed by the number of bits to be returned by the pseudorandom generator in every iteration for the step 2 (reordering)   (only for encrypting)
# -numBytesFileSlice followed by the number of bytes of every slice. It is recommended to use a high value for this parameter. The memory used by the process will be bounded by roughly 100 hundred times the slice size.   (only for encrypting)
# -useFileSizeForEncryptingParams if this parameter is present, the parameters of the encryption (defined by the previous 5 parameters) will calculated based on the size of the file to encrypt, and will overwrite these 5 previous parameters.
#########################################################################

java -cp "$APPLICATION_FOLDER/lib/libGeneral.jar:$APPLICATION_FOLDER/lib/libChaoticEncrypting.jar:$APPLICATION_FOLDER/lib/libConfiguration.jar:$APPLICATION_FOLDER/lib/FileEncoder.jar" com.hotmail.frojasg1.applications.fileencoder.FileEncoder "$1" "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "$10" "$11" "$12" "$13" "$14" "$15" "$16" "$17" "$18" "$19" "$20" "$21" "$22" "$23" "$24"

