#!/bin/bash

# the call to the command for encyrption uses the file size to choose the parameters for encryption.
# you can remove the parameter -useFileSizeForEncryptingParams and put manually the other parameters of the encryption if you prefer it.
# here follows a summary of the parameters. For more details, please go to the handbook.

#########################################################################
# These are the parameters you can use to encode a file:
# -password    followed by a parameter with the password
# -encodedFileName   followed by a parameter with the encoded file name
# -decodedFileName   followed by a parameter with the decoded file name
# -encode or -decode to choose between encryption and decryption 
# -fileEncoderType   followed by the id of the fileEncoderType (1 deprecated or 2)
# -sizeOfNumbersSimpleEncoder followed by the size of the numbers for the step 1 (XOR)
# -sizeOfNumbersReordererEncoder followed by the size of the numbers for the step 2 (reordering)
# -numberOfBitsPerIterationSimpleEncoder followed by the number of bits to be returned by the pseudorandom generator in every iteration for the step 1 (XOR)
# -numberOfBitsPerIterationReordererEncoder followed by the number of bits to be returned by the pseudorandom generator in every iteration for the step 2 (reordering)
# -numBytesFileSlice followed by the number of bytes of every slice. It is recommended to use a high value for this parameter. The memory used by the process will be bounded by roughly 100 hundred times the slice size.
# -useFileSizeForEncryptingParams if this parameter is present, the parameters of the encryption (defined by the previous 5 parameters) will calculated based on the size of the file to encrypt, and will overwrite these 5 previous parameters.
#########################################################################


./command.interface.FileEncoder.sh -encode -decodedFileName "$1" -encodedFileName "$1.jfe" -useFileSizeForEncryptingParams -password "$2"

exit $?
