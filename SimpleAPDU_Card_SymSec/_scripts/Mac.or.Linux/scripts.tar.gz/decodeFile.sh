#!/bin/bash

if (( $# != 2 ))
then
    echo "Use:"
    echo "$0 fileToDecrypt password"
    exit 1
fi

ENCODED_FILE_NAME=$1
PASSWORD=$2
DECODED_FILE_NAME=$( echo $ENCODED_FILE_NAME | sed -e 's/\(.*\)\.jfe$/\1/' )

if [ "$ENCODED_FILE_NAME" = "$DECODED_FILE_NAME" ]
then
    echo "Extension of file to decode was not .jfe"
    exit 1
fi


./command.interface.FileEncoder.sh -decode -decodedFileName "$DECODED_FILE_NAME" -encodedFileName "$ENCODED_FILE_NAME" -password "$PASSWORD"

exit $?
