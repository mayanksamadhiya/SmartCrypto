package com.hotmail.frojasg1.general;

public class GeneralException extends Exception
{
	public GeneralException( String text )
	{
		super( text );
	}
}
