/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hotmail.frojasg1.applications.common.components.internationalization;

import com.hotmail.frojasg1.applications.common.configuration.ConfigurationException;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextComponent;
import java.util.List;
import java.util.Properties;
import java.util.Vector;
import javax.swing.AbstractButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import javax.swing.JRootPane;
import javax.swing.ListModel;
import javax.swing.text.JTextComponent;

/**
 *
 * @author Fran
 */
public class JFrameInternationalization
{
	protected float a_lastFactor = 1.0F;

	FormLanguageConfiguration a_formLanguageConfiguration = null;
	FormGeneralConfiguration a_formGeneralConfiguration = null;

	protected static String	sa_dirSeparator = System.getProperty( "file.separator" );
	protected static String	sa_lineSeparator = System.getProperty( "line.separator" );

	protected static final String TXT_TEXT = "TEXT";
	protected static final String TXT_ELEMENT_AT = "ELEMENT_AT";
	protected static final String TXT_LABEL = "LABEL";
	protected static final String TXT_ITEM = "ITEM";
	protected static final String TXT_TITLE = "TITLE";

	protected Vector<JPopupMenu> a_vectorJpopupMenus = null;
	protected Component a_parentFrame = null;
	protected Component a_parentParentFrame = null;
	protected String a_configurationBaseFileName = null;
	
	public JFrameInternationalization(	String mainFolder,
										String applicationName,
										String group,
										String paquetePropertiesIdiomas,
										String configurationBaseFileName,
										Component parentFrame,
										Component parentParentFrame,
										Vector<JPopupMenu> vPUMenus,
										boolean hasToPutWindowPosition
									)
	{
		a_vectorJpopupMenus = vPUMenus;
		a_parentFrame = parentFrame;
		a_parentParentFrame = parentParentFrame;

		a_configurationBaseFileName = configurationBaseFileName;
		String languageConfigurationFileName = configurationBaseFileName + "_LAN.properties";
		String generalConfigurationFileName = configurationBaseFileName + "_GEN.properties";

		Properties prop = new Properties();
		try
		{
			convertTextsIntoProperties(prop, a_parentFrame, 0 );
		}
		catch (InternException ex)
		{
			ex.printStackTrace();
		}

		a_formLanguageConfiguration = new FormLanguageConfiguration(
								mainFolder,
								applicationName, group,
								languageConfigurationFileName,
								paquetePropertiesIdiomas,
								prop);
		a_formGeneralConfiguration = new FormGeneralConfiguration(
								mainFolder,
								applicationName, group,
								generalConfigurationFileName );

		try
		{
			a_formGeneralConfiguration.M_openConfiguration();
//			if( hasToPutWindowPosition && !a_formGeneralConfiguration.M_isFirstTime() ) putWindowPosition();
			putWindowPosition(hasToPutWindowPosition);
		}
		catch( ConfigurationException ce )
		{
			ce.printStackTrace();
		}

		a_lastFactor = 1.0F;
	}

	protected void putWindowPosition(boolean hasToPutWindowPosition)
	{
		try
		{
			if( !a_formGeneralConfiguration.M_isFirstTime() )
			{
				if( hasToPutWindowPosition )
				{
					a_parentFrame.setBounds(	(int) a_formGeneralConfiguration.M_getIntParamConfiguration( FormGeneralConfiguration.CONF_POSICION_X),
												(int) a_formGeneralConfiguration.M_getIntParamConfiguration(FormGeneralConfiguration.CONF_POSICION_Y),
												(int) a_formGeneralConfiguration.M_getIntParamConfiguration(FormGeneralConfiguration.CONF_ANCHO_VENTANA),
												(int) a_formGeneralConfiguration.M_getIntParamConfiguration(FormGeneralConfiguration.CONF_ALTO_VENTANA)
											);
				}
				else if( a_parentFrame instanceof Frame )
				{
					Frame frame = (Frame) a_parentFrame;
					if( frame.isResizable() )
					{
						a_parentFrame.setSize(	(int) a_formGeneralConfiguration.M_getIntParamConfiguration(FormGeneralConfiguration.CONF_ANCHO_VENTANA),
												(int) a_formGeneralConfiguration.M_getIntParamConfiguration(FormGeneralConfiguration.CONF_ALTO_VENTANA)
											);
					}
				}
				else
				{
					a_parentFrame.setSize(	(int) a_formGeneralConfiguration.M_getIntParamConfiguration(FormGeneralConfiguration.CONF_ANCHO_VENTANA),
											(int) a_formGeneralConfiguration.M_getIntParamConfiguration(FormGeneralConfiguration.CONF_ALTO_VENTANA)
										);
				}
			}
			else if( (a_parentParentFrame != null) && hasToPutWindowPosition )
				a_parentFrame.setLocation(	new Double( a_parentParentFrame.getLocationOnScreen().getX() ).intValue(),
											new Double( a_parentParentFrame.getLocationOnScreen().getY() ).intValue() + 50 );
			else if ( hasToPutWindowPosition )
			{
				int width = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
				int height = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
				a_parentFrame.setLocation( width/2 - a_parentFrame.getWidth()/2, height/2 - a_parentFrame.getHeight()/2 );
			}
		}
		catch( Throwable th )
		{
			th.printStackTrace();
		}
	}

	protected void getConfigurationChanges()
	{
		a_formGeneralConfiguration.M_setIntParamConfiguration(FormGeneralConfiguration.CONF_ALTO_VENTANA, a_parentFrame.getHeight() );
		a_formGeneralConfiguration.M_setIntParamConfiguration(FormGeneralConfiguration.CONF_ANCHO_VENTANA, a_parentFrame.getWidth() );
		a_formGeneralConfiguration.M_setIntParamConfiguration(FormGeneralConfiguration.CONF_POSICION_X, a_parentFrame.getX() );
		a_formGeneralConfiguration.M_setIntParamConfiguration(FormGeneralConfiguration.CONF_POSICION_Y, a_parentFrame.getY() );
	}

	public void M_saveGeneralConfiguration() throws ConfigurationException
	{
		getConfigurationChanges();
		a_formGeneralConfiguration.M_saveConfiguration();
	}
	
	public void saveConfiguration( ) throws InternException
	{
		try
		{
			M_saveGeneralConfiguration();
			saveLanguageConfiguration();
		}
		catch( ConfigurationException ex )
		{
			ex.printStackTrace();
			throw new InternException( "EXCEPTION: Saving form configuration of form : " +
										a_configurationBaseFileName +
										sa_lineSeparator + ex.getMessage() );
		}
	}

	protected void convertJPopUpMenuTextsIntoProperties( Properties prop, JPopupMenu jpumnu )
	{
		String name = jpumnu.getName();
//		addProperty( prop, name + "." + TXT_TEXT, jpumnu.getText() );
	}

	protected void convertAbstractButtonTextsIntoProperties( Properties prop, AbstractButton absbtn ) throws InternException
	{
		String name = absbtn.getName();
		if( ( name != null ) && ( !name.equals("") ) )
		{
			addProperty( prop, name + "." + TXT_TEXT, absbtn.getText() );

			if( absbtn instanceof JMenu )
			{
				JMenu jmnu = (JMenu) absbtn;
				for( int ii=0; ii<jmnu.getMenuComponentCount(); ii++ )
					convertTextsIntoProperties( prop, jmnu.getMenuComponent( ii ), 2 );
			}
		}
	}

	protected void convertJLabelTextsIntoProperties( Properties prop, JLabel jlbl )
	{
		String name = jlbl.getName();
		if( ( name != null ) && ( !name.equals("") ) ) addProperty( prop, name + "." + TXT_TEXT, jlbl.getText() );
	}

	protected void convertJListTextsIntoProperties( Properties prop, JList jlst )
	{
		String name = jlst.getName();
		if( ( name != null ) && ( !name.equals("") ) )
		{
			ListModel lm = jlst.getModel();
			for( int ii=0; ii<lm.getSize(); ii++ )
				addProperty( prop, name + "." + TXT_ELEMENT_AT + "." + String.valueOf(ii), lm.getElementAt(ii).toString() );
		}
	}

	protected void convertJTextComponentTextsIntoProperties( Properties prop, JTextComponent jtxtcmp )
	{
		String name = jtxtcmp.getName();
		if( ( name != null ) && ( !name.equals("") ) ) addProperty( prop, name + "." + TXT_TEXT, jtxtcmp.getText() );
	}

	protected void convertContainerTextsIntoProperties( Properties prop, Container contnr ) throws InternException
	{
		String name = contnr.getName();
		if( ( name != null ) && ( !name.equals("") ) )
		{
			if( contnr instanceof AbstractButton )
			{
				AbstractButton absbtn = (AbstractButton) contnr;
				convertAbstractButtonTextsIntoProperties( prop, absbtn );
			}
			else if( contnr instanceof JLabel )
			{
				JLabel jlbl = (JLabel) contnr;
				convertJLabelTextsIntoProperties( prop, jlbl );
			}
			else if( contnr instanceof JList )
			{
				JList jlst = (JList) contnr;
				convertJListTextsIntoProperties( prop, jlst );
			}
			else if( contnr instanceof JTextComponent )
			{
				JTextComponent jtxtcmp = (JTextComponent) contnr;
				convertJTextComponentTextsIntoProperties( prop, jtxtcmp );
			}
			else if( contnr instanceof JPopupMenu )
			{
				JPopupMenu jpumnu = (JPopupMenu) contnr;
				convertJPopUpMenuTextsIntoProperties( prop, jpumnu );
			}
			else if( contnr instanceof JFrame )
			{
				JFrame jfr = (JFrame) contnr;
				convertJFrameTextsIntoProperties( prop, jfr );
			}
			else if( contnr instanceof JInternalFrame )
			{
				JInternalFrame jif = (JInternalFrame) contnr;
				convertJInternalFrameTextsIntoProperties( prop, jif );
			}
		}
	}

	protected void addProperty( Properties prop, String label, String value )
	{
		prop.setProperty( label, value);
	}

	protected void convertButtonTextsIntoProperties( Properties prop, Button btn )
	{
		String name = btn.getName();
		if( ( name != null ) && ( !name.equals("") ) ) addProperty( prop, name + "." + TXT_LABEL, btn.getLabel() );
	}

	protected void convertCheckBoxTextsIntoProperties( Properties prop, Checkbox ckb )
	{
		String name = ckb.getName();
		if( ( name != null ) && ( !name.equals("") ) ) addProperty( prop, name + "." + TXT_LABEL, ckb.getLabel() );
	}

	protected void convertChoiceTextsIntoProperties( Properties prop, Choice chc )
	{
		String name = chc.getName();
		if( ( name != null ) && ( !name.equals("") ) )
		{
			for( int ii=0; ii<chc.getItemCount(); ii++ )
				addProperty( prop, name + "." + TXT_ITEM + "." + String.valueOf(ii), chc.getItem(ii) );
		}
	}

	protected void convertLabelTextsIntoProperties( Properties prop, Label lbl )
	{
		String name = lbl.getName();
		if( ( name != null ) && ( !name.equals("") ) ) addProperty( prop, name + "." + TXT_TEXT, lbl.getText() );
	}

	protected void convertListTextsIntoProperties( Properties prop, List lst )
	{
//		String name = lst.getName();
	}

	protected void convertTextComponentTextsIntoProperties( Properties prop, TextComponent txtcmp )
	{
		String name = txtcmp.getName();
	}

	protected void convertJFrameTextsIntoProperties( Properties prop, JFrame jfr )
	{
		String name = jfr.getName();
		if( ( name != null ) && ( !name.equals("") ) ) addProperty( prop, name + "." + TXT_TITLE, jfr.getTitle() );
	}

	protected void convertJInternalFrameTextsIntoProperties( Properties prop, JInternalFrame jif )
	{
		String name = jif.getName();

//		addProperty( prop, name + "." + TXT_TITLE, jif.getTitle() );
	}

	protected void convertTextsIntoProperties( Properties prop, Component comp, int level ) throws InternException
	{
		level = level + 1;
		if( level == 1 )
		{
			if( a_vectorJpopupMenus != null )
			{
				for( int ii=0; ii<a_vectorJpopupMenus.size(); ii++ )
				{
					convertTextsIntoProperties( prop, a_vectorJpopupMenus.elementAt(ii), level );
				}
			}
		}

		String name = comp.getName();
		if( ( ( name != null ) && ( !name.equals("") ) ) || ( comp instanceof JRootPane ) )
		{
			if( comp instanceof JDesktopPane )
			{
			}
			else if( comp instanceof Container	)
			{
				Container contnr = (Container) comp;
				convertContainerTextsIntoProperties( prop, contnr );
				for( int ii=0; ii<contnr.getComponentCount(); ii++ )
				{
					convertTextsIntoProperties( prop, contnr.getComponent(ii), level );
				}
			}
			else if( comp instanceof Button )
			{
				Button btn = (Button) comp;
				convertButtonTextsIntoProperties( prop, btn );
			}
			else if( comp instanceof Checkbox )
			{
				Checkbox ckb = (Checkbox) comp;
				convertCheckBoxTextsIntoProperties( prop, ckb );
			}
			else if( comp instanceof Choice )
			{
				Choice chc = (Choice) comp;
				convertChoiceTextsIntoProperties( prop, chc );
			}
			else if( comp instanceof Label )
			{
				Label lbl = (Label) comp;
				convertLabelTextsIntoProperties( prop, lbl );
			}
			else if( comp instanceof	List )
			{
				List lst = (List) comp;
				convertListTextsIntoProperties( prop, lst );
			}
			else if( comp instanceof TextComponent )
			{
				TextComponent txtcmp = (TextComponent) comp;
				convertTextComponentTextsIntoProperties( prop, txtcmp );
			}
			else
			{
				throw new InternException( "Class of component not expected. " + comp.getClass().getName() );
			}
		}
	}

	protected void convertPropertiesIntoAbstractButtonTexts( Properties prop, AbstractButton absbtn ) throws InternException
	{
		String name = absbtn.getName();

		if( ( name != null ) && ( !name.equals("") ) )
		{
			String value = prop.getProperty( name + "." + TXT_TEXT );

			if( value != null )
				absbtn.setText( value );
			else
				System.out.println("Error cargando propiedades de idioma de " + name + " en " + a_parentFrame.getName() );

			if( absbtn instanceof JMenu )
			{
				JMenu jmnu = (JMenu) absbtn;
				for( int ii=0; ii<jmnu.getMenuComponentCount(); ii++ )
					convertPropertiesIntoTexts( prop, jmnu.getMenuComponent( ii ), 2 );
			}
		}
	}

	protected void convertPropertiesIntoJLabelTexts( Properties prop, JLabel jlbl ) throws InternException
	{
		String name = jlbl.getName();

		if( ( name != null ) && ( !name.equals("") ) )
		{
			String value = prop.getProperty( name + "." + TXT_TEXT );

			if( value != null )
				jlbl.setText( value );
			else
			{
//				throw new InternException( "Error cargando propiedades de idioma de " + name + " en " + a_frameParent.getName() );
			}
		}
	}

	protected void convertPropertiesIntoJListTexts( Properties prop, JList jlst ) throws InternException
	{
/*
		String name = jlst.getName();

		DefaultListModel dlm = new DefaultListModel();
		String value = "";
		for( int ii=0; ( value != null ); ii++ )
		{
			value = prop.getProperty( name + "." + TXT_TEXT + "." + String.valueOf(ii) );
			if( value != null )
				dlm.setElementAt( value, ii );
		}
		jlst.setModel( dlm );
 */
	}

	protected void convertPropertiesIntoJTextComponentTexts( Properties prop, JTextComponent jtxtcmp ) throws InternException
	{
		String name = jtxtcmp.getName();
	}

	protected void convertPropertiesIntoJPopUpMenuTexts( Properties prop, JPopupMenu jpumnu ) throws InternException
	{
		String name = jpumnu.getName();
//		addProperty( prop, name + "." + TXT_TEXT, jpumnu.getText() );
	}

	protected void convertPropertiesIntoContainerTexts( Properties prop, Container contnr ) throws InternException
	{
		String name = contnr.getName();

		if( ( name != null ) && ( !name.equals("") ) )
		{
			if( contnr instanceof AbstractButton )
			{
				AbstractButton absbtn = (AbstractButton) contnr;
				convertPropertiesIntoAbstractButtonTexts( prop, absbtn );
			}
			else if( contnr instanceof JLabel )
			{
				JLabel jlbl = (JLabel) contnr;
				convertPropertiesIntoJLabelTexts( prop, jlbl );
			}
			else if( contnr instanceof JList )
			{
				JList jlst = (JList) contnr;
				convertPropertiesIntoJListTexts( prop, jlst );
			}
			else if( contnr instanceof JTextComponent )
			{
				JTextComponent jtxtcmp = (JTextComponent) contnr;
				convertPropertiesIntoJTextComponentTexts( prop, jtxtcmp );
			}
			else if( contnr instanceof JPopupMenu )
			{
				JPopupMenu jpumnu = (JPopupMenu) contnr;
				convertPropertiesIntoJPopUpMenuTexts( prop, jpumnu );
			}
			else if( contnr instanceof JFrame )
			{
				JFrame jfr = (JFrame) contnr;
				convertPropertiesIntoJFrameTexts( prop, jfr );
			}
			else if( contnr instanceof JInternalFrame )
			{
				JInternalFrame jif = (JInternalFrame) contnr;
				convertPropertiesIntoJInternalFrameTexts( prop, jif );
			}
		}
	}

	protected void convertPropertiesIntoButtonTexts( Properties prop, Button btn ) throws InternException
	{
		String name = btn.getName();
		if( name !=  null )
		{
			String value = prop.getProperty( name + "." + TXT_LABEL );

			if( value != null )
				btn.setLabel( value );
			else
			{
//				throw new InternException( "Error cargando propiedades de idioma de " + name + " en " + a_frameParent.getName() );
			}
		}
	}

	protected void convertPropertiesIntoCheckBoxTexts( Properties prop, Checkbox ckb ) throws InternException
	{
		String name = ckb.getName();
		if( ( name != null ) && ( !name.equals("") ) )
		{
			String value = prop.getProperty( name + "." + TXT_LABEL );

			if( value != null )
				ckb.setLabel( value );
			else
			{
//				throw new InternException( "Error cargando propiedades de idioma de " + name + " en " + a_frameParent.getName() );
			}
		}
	}

	protected void convertPropertiesIntoChoiceTexts( Properties prop, Choice chc ) throws InternException
	{
		String name = chc.getName();
		if( ( name != null ) && ( !name.equals("") ) )
		{
			chc.removeAll();

			String value = "";
			for( int ii=0; (value != null) && (ii<chc.getItemCount()); ii++ )
			{
				value = prop.getProperty( name + "." + TXT_ITEM + "." + String.valueOf(ii) );

				if( value != null )
					chc.add( value );
				else
				{
/*					throw new InternException(	"Needed property not found. " + name + "." + TXT_ITEM + "." + String.valueOf(ii) +
																			" in " + a_frameParent.getName() ); */
				}
			}
		}
	}

	protected void convertPropertiesIntoLabelTexts( Properties prop, Label lbl ) throws InternException
	{
		String name = lbl.getName();
		if( ( name != null ) && ( !name.equals("") ) )
		{
			String value = prop.getProperty( name + "." + TXT_TEXT );

			if( value != null )
				lbl.setText( value );
			else
			{
//				throw new InternException( "Error cargando propiedades de idioma de " + name + " en " + a_frameParent.getName() );
			}
		}
	}

	protected void convertPropertiesIntoListTexts( Properties prop, List lst ) throws InternException
	{
//		String name = lst.getName();
	}

	protected void convertPropertiesIntoTextComponentTexts( Properties prop, TextComponent txtcmp ) throws InternException
	{
		String name = txtcmp.getName();
	}

	protected void convertPropertiesIntoJFrameTexts( Properties prop, JFrame jfr ) throws InternException
	{
		String name = jfr.getName();
		if( ( name != null ) && ( !name.equals("") ) )
		{
			String value = prop.getProperty( name + "." + TXT_TITLE );

			if( value != null )
				jfr.setTitle( value );
			else
			{
//				throw new InternException( "Error cargando propiedades de idioma de " + name + " en " + a_frameParent.getName() );
			}
		}
	}

	protected void convertPropertiesIntoJInternalFrameTexts( Properties prop, JInternalFrame jif ) throws InternException
	{
		String name = jif.getName();
		if( ( name != null ) && ( !name.equals("") ) )
		{
			String value = prop.getProperty( name + "." + TXT_TITLE );

			if( value != null )
				jif.setTitle( value );
			else
			{
//				throw new InternException( "Error cargando propiedades de idioma de " + name + " en " + a_frameParent.getName() );
			}
		}
	}

	protected void convertPropertiesIntoTexts( Properties prop, Component comp, int level ) throws InternException
	{
		level = level + 1;

		if( level == 1 )
		{
			if( a_vectorJpopupMenus != null )
			{
				for( int ii=0; ii<a_vectorJpopupMenus.size(); ii++ )
				{
					convertPropertiesIntoTexts( prop, a_vectorJpopupMenus.get(ii), level );
				}
			}
		}
		
		String name = comp.getName();
		if( ( name != null ) && ( !name.equals("") ) || ( comp instanceof JRootPane ) )
		{
			if( comp instanceof JDesktopPane )
			{
			}
			else if( comp instanceof Container	)
			{
				Container contnr = (Container) comp;
				convertPropertiesIntoContainerTexts( prop, contnr );
				for( int ii=0; ii<contnr.getComponentCount(); ii++ )
				{
					convertPropertiesIntoTexts( prop, contnr.getComponent(ii), level );
				}
			}
			else if( comp instanceof Button )
			{
				Button btn = (Button) comp;
				convertPropertiesIntoButtonTexts( prop, btn );
			}
			else if( comp instanceof Checkbox )
			{
				Checkbox ckb = (Checkbox) comp;
				convertPropertiesIntoCheckBoxTexts( prop, ckb );
			}
			else if( comp instanceof Choice )
			{
				Choice chc = (Choice) comp;
				convertPropertiesIntoChoiceTexts( prop, chc );
			}
			else if( comp instanceof Label )
			{
				Label lbl = (Label) comp;
				convertPropertiesIntoLabelTexts( prop, lbl );
			}
			else if( comp instanceof	List )
			{
				List lst = (List) comp;
				convertPropertiesIntoListTexts( prop, lst );
			}
			else if( comp instanceof TextComponent )
			{
				TextComponent txtcmp = (TextComponent) comp;
				convertPropertiesIntoTextComponentTexts( prop, txtcmp );
			}
			else
			{
				throw new InternException( "unexpected class of component " + comp.getClass().getName() );
			}
		}
	}

	public void M_changeLanguage( String language ) throws InternException
	{
		try
		{
			if( a_formLanguageConfiguration != null )
			{
				a_formLanguageConfiguration.M_changeLanguage( language );
				convertPropertiesIntoTexts(a_formLanguageConfiguration, a_parentFrame, 0 );
			}
		}
		catch( ConfigurationException ce )
		{
			ce.printStackTrace();
			throw( new InternException( ce.getMessage() ) );
		}
	}

	protected void saveLanguageConfiguration() throws InternException
	{
		if( a_formLanguageConfiguration != null )
		{
			convertTextsIntoProperties(a_formLanguageConfiguration, a_parentFrame, 0 );
			try
			{
				a_formLanguageConfiguration.M_saveConfiguration();
			}
			catch( ConfigurationException ex )
			{
				ex.printStackTrace();
				throw new InternException(	"Exception saving form configuration file for form: " + a_configurationBaseFileName );
			}
		}
	}
	
	public String M_getLanguage()
	{
		String result = null;
		
		if( a_formLanguageConfiguration != null ) result = a_formLanguageConfiguration.M_getLanguage();
		
		return( result );
	}

	protected void changeFontSize( Component comp, float factor )
	{
		Font oldFont = comp.getFont();
		if( oldFont != null )
		{
			Font newFont = oldFont.deriveFont( (float) Math.round( factor * comp.getFont().getSize() ) );
			comp.setFont( newFont );
		}
	}

	protected void changeFontSizeRecursive( Component comp, float factor )
	{

		if( !(comp instanceof JInternalFrame) )
		{
			changeFontSize( comp, factor );
			if( comp instanceof Container	)
			{
				Container contnr = (Container) comp;
				for( int ii=0; ii<contnr.getComponentCount(); ii++ )
				{
					changeFontSizeRecursive( contnr.getComponent(ii), factor );
				}

				if( comp instanceof JMenu )
				{
					JMenu jmnu = (JMenu) comp;
					for( int ii=0; ii<jmnu.getMenuComponentCount(); ii++ )
						changeFontSizeRecursive( jmnu.getMenuComponent( ii ), factor );
				}
			}
		}
	}

	public void M_changeFontSize( float factor )
	{
		if( factor > 0 )
		{
			float newFactor = factor / a_lastFactor;
			
			if( (a_parentFrame != null) && (a_parentFrame instanceof Container ) )
			{
				Container cont = (Container) a_parentFrame;
				for( int ii=0; ii<cont.getComponentCount(); ii++ )
				{
					changeFontSizeRecursive( cont.getComponent(ii), newFactor );
				}
			}
			else
			{
				changeFontSizeRecursive( a_parentFrame, factor );
			}

			if( a_vectorJpopupMenus != null )
			{
				for( int ii=0; ii<a_vectorJpopupMenus.size(); ii++ )
				{
					changeFontSizeRecursive( a_vectorJpopupMenus.get(ii), newFactor );
				}
			}
			
			a_lastFactor = factor;
		}
	}
}
