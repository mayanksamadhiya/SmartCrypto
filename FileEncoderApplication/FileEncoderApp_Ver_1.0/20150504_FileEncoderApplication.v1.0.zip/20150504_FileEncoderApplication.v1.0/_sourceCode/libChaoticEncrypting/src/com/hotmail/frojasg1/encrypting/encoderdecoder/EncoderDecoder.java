package com.hotmail.frojasg1.encrypting.encoderdecoder;

import com.hotmail.frojasg1.encrypting.pseudorandomgenerator.PseudoRandomGeneratorException;

public interface EncoderDecoder
{
	public void M_initializeKey( byte[] newKey ) throws PseudoRandomGeneratorException;
	public void M_initializeKey( String newHexKey ) throws PseudoRandomGeneratorException;
	public byte[] M_encode( byte[] input ) throws PseudoRandomGeneratorException;
	public byte[] M_decode( byte[] input ) throws PseudoRandomGeneratorException;

	public int M_getRecommendedNumberOfBytesToInitializeKey();
}
