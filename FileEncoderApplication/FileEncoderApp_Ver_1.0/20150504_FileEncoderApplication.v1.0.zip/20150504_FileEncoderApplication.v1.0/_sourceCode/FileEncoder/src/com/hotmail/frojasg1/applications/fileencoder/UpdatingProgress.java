/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hotmail.frojasg1.applications.fileencoder;

/**
 *
 * @author Usuario
 */
public interface UpdatingProgress
{
	public void M_beginProgress();
	public void M_updateProgress( int completedPercentage );
	public void M_endProgress();
}
