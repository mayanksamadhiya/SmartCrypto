=========== ENGLISH
Readme:

Decrypt the file scripts.zip.jfe with the application with an empty password.
Then unzip the file scripts.zip, and you will get the scripts for windows.

===============================================================================

=========== CASTELLANO
Leeme:

Desencripta el fichero scripts.zip.jfe con la aplicaci�n con una contrase�a vac�a.
Despu�s descomprime el fichero scripts.zip, y obtendr�s los scripts para windows.

===============================================================================

=========== CATAL�
Llegeig-me:

Desencripta l'arxiu scripts.zip.jfe amb l'aplicaci� amb una contrasenya buida.
Despr�s descomprimeix l'arxiu scripts.zip i obtindr�s els scripts per windows.

